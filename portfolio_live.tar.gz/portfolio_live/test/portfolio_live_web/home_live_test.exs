defmodule PortfolioLiveWeb.HomeLiveTest do
  use PortfolioLiveWeb.ConnCase

  import Phoenix.LiveViewTest

  test "renders the hero content", %{conn: conn} do
    {:ok, view, _html} = live(conn, ~p"/")

    assert has_element?(view, "p", "Design.Product.Engineering")
    assert has_element?(view, "a", "Get in touch")
    assert has_element?(view, "nav", "Case Studies")
  end
end
