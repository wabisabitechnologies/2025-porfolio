%{
  slug: "showcasing-the-community",
  title: "Showcasing the community",
  category: "Social experiences",
  summary: "Designed an adaptive feed that lets members highlight work while the team rapidly shipped new feature types.",
  hero_image: "https://framerusercontent.com/images/zf6LxLgW17Coi1PMuGEvhAMMtXo.webp?width=1600",
  stats: [
    %{label: "Discoveries per day", value: "43% ↑"},
    %{label: "Time to ship", value: "11 weeks"}
  ],
  context: [
    %{label: "Duration", value: "8 weeks"},
    %{label: "Team", value: "7 designers & engineers"},
    %{label: "Scope", value: "Product Strategy / Design Systems"}
  ],
  sections: [
    %{
      type: "text",
      title: "Community-first strategy",
      body:
        "We reframed the feed as a rotating stage for the community instead of a static list of posts. That meant the design system had to support campaigns, shoutouts, and drop-in formats without engineering involvement."
    },
    %{
      type: "image",
      caption: "Adaptive card system for highlights, prompts, and campaigns",
      src: "https://framerusercontent.com/images/zf6LxLgW17Coi1PMuGEvhAMMtXo.webp?width=1600"
    },
    %{
      type: "text",
      title: "What shipped",
      body:
        "We codified six card templates, layered them into a schedule, and gave the editorial team a visual planner. The rollout included guidelines for photography, copy anchors, and instrumentation so PMs could measure which cards converted best."
    }
  ],
  tags: ["Product", "Systems"],
  featured: true
}
---

We replaced a static editorial feed with a modular system that allowed new templates to be assembled in under a day. This brought experimentation velocity up without sacrificing polish.

