%{
  slug: "simple-formations",
  title: "Scaling incorporations",
  category: "Simple Formations",
  summary: "Led the product vision for a guided incorporation flow used by thousands of founders.",
  hero_image: "https://framerusercontent.com/images/fqyjCDbGm7R1AekelRPdY1744.webp?width=1600",
  stats: [
    %{label: "Conversion lift", value: "28% ↑"},
    %{label: "Avg. completion", value: "9m 12s"}
  ],
  context: [
    %{label: "Duration", value: "11 weeks"},
    %{label: "Team", value: "10 cross-functional builders"},
    %{label: "Scope", value: "Product Lead / IC"}
  ],
  sections: [
    %{
      type: "text",
      title: "Where we started",
      body:
        "Founders had to jump between legal documents, spreadsheets, and vendor forms just to understand which entity type to choose. We mapped the inside sales process, consolidated the best reps’ scripts, and turned them into lightweight prompts users could answer in seconds."
    },
    %{
      type: "image",
      caption: "Scenario-based wizard with contextual education",
      src: "https://framerusercontent.com/images/fqyjCDbGm7R1AekelRPdY1744.webp?width=1600"
    },
    %{
      type: "quote",
      quote:
        "We shipped a fully guided incorporation flow in under three months and cut onboarding time by 37%.",
      cite: "COO, Simple Formations"
    }
  ],
  tags: ["Product", "Design", "Research"],
  featured: true
}
---

The new experience paired scenario-based questions with contextual education, reducing legal handoffs and creating a clearer path to launch for non-technical founders.

