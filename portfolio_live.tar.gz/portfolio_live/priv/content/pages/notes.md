%{
  slug: "notes",
  title: "Notes & Field Reports",
  summary: "Quick captures across product, design, engineering, and business so updates stay lightweight but useful.",
  sidebar_links: [
    %{
      label: "Categories",
      items: ["Product", "Design", "Engineering", "Business"]
    }
  ]
}
---

Short reflections on what shipped, what we learned, and how the team or business adjusted.

