%{
  slug: "case-studies",
  title: "Case Studies",
  summary: "A sampling of product work across consumer and B2B surfaces, each balancing clarity with pace.",
  availability: "Available for Q4 2025",
  cta: [
    %{label: "Get in touch", href: "mailto:alex@cosmas.studio"},
    %{label: "Book a call", href: "https://cal.com/alexcosmas"}
  ],
  sidebar_links: [
    %{
      label: "Tags",
      items: ["UX Development", "Product Strategy", "Design Systems"]
    },
    %{
      label: "Case Studies",
      items: [
        %{label: "Simple Formations", href: "/case-studies/simple-formations"},
        %{label: "Showcasing the community", href: "/case-studies/showcasing-the-community"}
      ]
    }
  ]
}
---

Deep dives on zero-to-one surfaces, go-to-market enablement, and iterative improvements that compound over time.

