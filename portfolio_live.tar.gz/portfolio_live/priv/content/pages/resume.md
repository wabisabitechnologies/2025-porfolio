%{
  slug: "resume",
  title: "Resume",
  summary: "Highlights across leadership, product delivery, and advisory work.",
  sidebar_links: [
    %{label: "Download", href: "https://example.com/alex-cosmas-resume.pdf"},
    %{label: "Contact", href: "mailto:alex@cosmas.studio"}
  ]
}
---

### Experience

**Product Lead · Simple Formations**  
2023 — Present  
- Built the onboarding flow that reduced time-to-incorporate by 37%  
- Led a cross-functional pod spanning design, engineering, and ops  
- Introduced KPI reviews and weekly artifact critique

**CPO & Founder · WabiSabi Technologies**  
2018 — 2023  
- Scaled a consumer platform for creative communities to 200k users  
- Launched a marketplace that grew GMV 4x in twelve months  
- Raised and deployed seed capital, hiring the first 15 teammates

**Design Lead · Independent**  
2014 — 2018  
- Partnered with venture studios on zero-to-one experiments  
- Delivered multi-platform systems for media and fintech clients

### Selected Skills

- Product Strategy & Narrative  
- Design Systems & Prototyping  
- Experimentation & Measurement  
- Team Formation & Operations

