%{
  slug: "about",
  title: "About",
  summary: "Partnering with founders and teams to define narratives, build products, and guide multidisciplinary squads.",
  body_intro: "Alex blends product strategy and systems thinking to bring ambiguous briefs into focus.",
  sidebar_links: [
    %{
      label: "Focus Areas",
      items: ["Product & Venture Strategy", "Design Leadership", "Engineering Collaboration"]
    },
    %{
      label: "Writing",
      items: [
        %{label: "Principles for fast-moving teams", href: "/notes#note-principles-fast-moving-teams"},
        %{label: "Bringing heuristics to shipping cadence", href: "/notes#note-bringing-heuristics-to-shipping"}
      ]
    }
  ]
}
---

### Background

Over the past decade Alex has led product initiatives for fintech, creator tools, and data platforms. He advises several early-stage startups, helping them create clear product narratives while building their first cross-functional hires.

### Approach

- Clarify hypotheses early with narrative decks and prototypes  
- Establish operating rhythms so decisions move faster  
- Pair designers and engineers to ship usable increments weekly  
- Keep incentives transparent so the team can focus on outcomes

### Collaboration

Alex typically works as an embedded product lead or interim CPO, shaping strategy, hands-on design, and aligning executives around shared context. He plugs into existing teams or builds pods tailored to the roadmap.

