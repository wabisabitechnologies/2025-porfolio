%{
  slug: "engineering-handshake",
  title: "Engineering handshake notes",
  published_at: ~D[2025-11-08],
  summary: "Capture API contracts, delivery risks, and logging expectations before kickoff to keep handoffs tight.",
  category: "Engineering",
  tags: ["Engineering", "Delivery"]
}
---

Write the handshake in Notion or Slack with three bullets: integration points, known migrations, and the monitoring hooks you’ll add. Anything missing there becomes debt later.

