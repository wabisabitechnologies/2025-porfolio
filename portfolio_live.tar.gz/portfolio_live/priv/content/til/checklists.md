%{
  slug: "til-checklists",
  title: "Checklist snapshots",
  published_at: ~D[2025-11-05],
  summary: "When a review stalls, write the 3 checks in a til so the next pass is faster.",
  category: "Business",
  tags: ["Craft", "Teams"]
}
---

Before kicking off async reviews, jot a three-item checklist in `/til`. It clarifies expectations and doubles as a public artifact of what “done” looked like for that day.

