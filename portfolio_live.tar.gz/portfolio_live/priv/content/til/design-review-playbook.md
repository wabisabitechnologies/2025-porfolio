%{
  slug: "design-review-playbook",
  title: "Faster design reviews",
  published_at: ~D[2025-11-12],
  summary: "Keep reviews under 20 minutes by anchoring on the customer problem, the north-star principle, and the primary risk.",
  category: "Design",
  tags: ["Design", "Rituals"]
}
---

Show only the latest explorations, speak to the framing, and close with a single decision request. Anything more turns a review into a status meeting.

