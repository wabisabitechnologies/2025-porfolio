%{
  slug: "bringing-heuristics-to-shipping",
  title: "Bringing heuristics to shipping cadence",
  published_at: ~D[2025-10-05],
  summary: "How I keep experiments honest by pairing heuristics with weekly delivery rituals.",
  category: "Business",
  tags: ["Operations", "Experimentation"]
}
---

Write the heuristic, socialize it, and then measure the release against it. If a launch doesn’t move the needle, the heuristic changes before the team ships again.



