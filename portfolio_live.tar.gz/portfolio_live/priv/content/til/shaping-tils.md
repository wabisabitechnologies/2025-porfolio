%{
  slug: "shaping-tils",
  title: "Shaping quick TILs",
  published_at: ~D[2025-11-10],
  summary: "Capture a tiny insight, add a tag, publish in seconds.",
  category: "Product",
  tags: ["Process"]
}
---

Keep a `/til` folder in your repo and drop a Markdown file with three fields: title, summary, and date. Ship it without polishing—momentum beats perfection.

