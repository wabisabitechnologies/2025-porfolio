%{
  slug: "principles-fast-moving-teams",
  title: "Principles for fast-moving teams",
  published_at: ~D[2025-10-18],
  summary: "A short playbook I share with new collaborators on how to keep quality high when speed matters.",
  category: "Product",
  tags: ["Leadership", "Process"]
}
---

1. Align on the narrative, not the feature list.
2. Decide what “good” looks like before opening Figma.
3. Ship the smallest possible win, then layer polish as you learn.



