# Kamal Deployment Playbook

This playbook ensures consistent deployment setup for all projects deployed to the VPS using Kamal.

## Project Structure

All projects on the VPS follow this structure:
```
/projects/<category>/<projectname>
```

**Example:**
- `/projects/personal/portfolio`
- `/projects/work/client-app`
- `/projects/experimental/test-project`

## Pre-Deployment Checklist

Before deploying any project, verify the following:

### ✅ 1. Project Directory Structure
- [ ] Project directory exists on VPS: `/projects/<category>/<projectname>`
- [ ] Directory owned by `alex:alex`
- [ ] Directory permissions: `755`

**Setup Command:**
```bash
ssh alex@38.242.204.55 "sudo mkdir -p /projects/<category>/<projectname> && sudo chown alex:alex /projects/<category>/<projectname>"
```

### ✅ 2. SSH Access Configured
- [ ] SSH key-based authentication works: `ssh alex@38.242.204.55 'echo success'`
- [ ] No password prompt required
- [ ] SSH key added to VPS `~/.ssh/authorized_keys`

**Setup Command:**
```bash
# From local machine, add your public key to VPS
ssh-copy-id alex@38.242.204.55
# OR manually add to ~/.ssh/authorized_keys on VPS
```

### ✅ 3. Docker Configuration
- [ ] Docker installed on VPS: `ssh alex@38.242.204.55 'docker --version'`
- [ ] User `alex` in docker group: `ssh alex@38.242.204.55 'groups | grep docker'`
- [ ] Docker daemon running

**Setup Commands:**
```bash
ssh alex@38.242.204.55 << 'EOF'
sudo apt update
sudo apt install -y docker.io docker-compose-plugin
sudo usermod -aG docker alex
newgrp docker
docker --version
EOF
```

### ✅ 4. Kamal Configuration Files
- [ ] Single `deploy.yml` lives in project root (no duplicate copies)
- [ ] `.kamal/secrets` directory exists (git-ignored)
- [ ] Secrets file contains required variables:
  - `SECRET_KEY_BASE` (for Phoenix/Elixir apps)
  - Any other project-specific secrets (e.g., `DATABASE_URL`)

**Required Files:**
```
project-root/
├── deploy.yml
├── Dockerfile
├── .dockerignore
└── .kamal/
    └── secrets (git-ignored)
```

### ✅ 5. Dockerfile Present
- [ ] `Dockerfile` exists in project root
- [ ] Dockerfile builds successfully: `docker build -t test .`
- [ ] Image size is reasonable (check with `docker images`)

### ✅ 6. (Optional) CI/CD
- Manual Kamal deploys are the default.
- If future automation is needed, document the workflow in this repo before enabling it.

### ✅ 7. Domain/Proxy Configuration
- [ ] `deploy.yml` includes `proxy` section
- [ ] Host configured: `alex.38.242.204.55.nip.io`
- [ ] SSL enabled if needed: `ssl: true`
- [ ] Ports 80/443 open on VPS firewall
- [ ] Direct IP access blocked (domain-only access)
- [ ] Dynamic port assignment (no fixed port mapping)

**Firewall Setup:**
```bash
ssh alex@38.242.204.55 << 'EOF'
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
sudo ufw status
EOF
```

### ✅ 8. Remote Builder Configuration
- [ ] `deploy.yml` uses `builder.remote: ssh://alex@38.242.204.55` to build images directly on VPS
- [ ] No registry credentials needed (images never leave the server)
- [ ] VPS has enough disk space for Docker builds and images

## Deployment Process

### Initial Setup (First Time)
```bash
# 1. Create project directory on VPS
ssh alex@38.242.204.55 "sudo mkdir -p /projects/<category>/<projectname> && sudo chown alex:alex /projects/<category>/<projectname>"

# 2. Generate secrets
mix phx.gen.secret  # For Phoenix apps
# Store in .kamal/secrets

# 3. Bootstrap Kamal proxy (first project only)
kamal proxy bootstrap -c deploy.yml

# 4. Initial deployment
kamal setup -c deploy.yml
```

### Manual Deployment
```bash
# Deploy latest changes (builds remotely on VPS, no registry needed)
kamal deploy -c deploy.yml

# Deploy specific version
kamal deploy -c deploy.yml --version <git-sha>

# Rollback
kamal rollback -c deploy.yml
```

## Verification Steps

After deployment, verify:

```bash
# 1. Check container is running
kamal app details -c deploy.yml

# 2. Check logs
kamal app logs -c deploy.yml

# 3. Test HTTP endpoint
curl -I http://alex.38.242.204.55.nip.io

# 4. SSH into VPS and verify
ssh alex@38.242.204.55 'docker ps | grep portfolio-live'
```

## Troubleshooting

### SSH Connection Issues
```bash
# Test SSH
ssh -v alex@38.242.204.55

# Check authorized_keys
ssh alex@38.242.204.55 'cat ~/.ssh/authorized_keys'
```

### Docker Issues
```bash
# Check Docker status
ssh alex@38.242.204.55 'sudo systemctl status docker'

# Check user in docker group
ssh alex@38.242.204.55 'groups'
```

### Deployment Failures
```bash
# Check Kamal logs
kamal app logs -c deploy.yml --lines 100

# Check container status
kamal app details -c deploy.yml

# View all containers
ssh alex@38.242.204.55 'docker ps -a'
```

## Project-Specific Notes

### Phoenix/Elixir Projects
- Requires `SECRET_KEY_BASE` secret
- Uses `mix phx.gen.secret` to generate
- Ensure `PHX_HOST` env var matches proxy host

### Node.js Projects
- May require `NODE_ENV=production`
- Check for build-time dependencies

### Python Projects
- May require virtual environment setup
- Check for system dependencies

## Maintenance

### Regular Tasks
- [ ] Monitor disk space: `ssh alex@38.242.204.55 'df -h'`
- [ ] Clean old Docker images: `kamal prune -c deploy.yml`
- [ ] Update Kamal: `gem update kamal`
- [ ] Review logs for errors

### Security
- [ ] Rotate secrets periodically
- [ ] Keep Docker images updated
- [ ] Review SSH key access
- [ ] Monitor firewall rules

## Quick Reference

```bash
# Check project setup
cat rule.md | grep "✅"

# Deploy manually (builds remotely on VPS)
kamal deploy -c deploy.yml

# View status
kamal app details -c deploy.yml

# View logs
kamal app logs -c deploy.yml -f

# Rollback
kamal rollback -c deploy.yml
```

