# PortfolioLive

Phoenix LiveView translation of Alex Cosmas' portfolio concept. The interface mirrors the provided layout with LiveView-only state management—no Ecto or database layer is configured so we can focus solely on the experience.

## Getting started

1. Install dependencies
   ```bash
   mix setup
   ```
2. Start the dev server
   ```bash
   mix phx.server
   ```
3. Open [`http://localhost:4000`](http://localhost:4000) to view the portfolio.

## Project notes

- Generated with `mix phx.new portfolio_live --no-ecto` to intentionally exclude database setup for now.
- All content is currently static assigns inside `PortfolioLiveWeb.HomeLive`; hook this up to real data sources when ready.
- Styling relies on Tailwind CSS with a light layer of custom tokens in `assets/css/app.css`.

Ready to run in production? Please [check the deployment guides](https://hexdocs.pm/phoenix/deployment.html).

## Deployment (Kamal)

1. Populate `ignore.txt` (never commit this file) with:
   - `VPS_SSH_PRIVATE_KEY`: full PEM private key corresponding to the VPS login you enabled.
   - `DOCKER_REGISTRY_PASSWORD`: Docker Hub token for `wabisabitech`.
   - `SECRET_KEY_BASE`: already generated, rotate with `mix phx.gen.secret` if needed.
   - `CONTABO_CLIENT_ID` / `CONTABO_CLIENT_SECRET`: values Contabo issued (`INT-14385098` / `aqz5tsy7ToIBClxWnj81fvOFjdE06hCj`).
2. Run Kamal commands with the helper script so secrets stay local:
   ```bash
   bin/kamal-from-ignore.sh setup -c deploy.yml   # first run
   bin/kamal-from-ignore.sh deploy -c deploy.yml  # subsequent deploys
   ```
   The script materializes `.kamal/secrets`, `.kamal/contabo.env`, and a temporary SSH key.
3. Mirror the same values inside GitHub → Settings → Secrets → Actions so the `Deploy to VPS` workflow can run on every push to `main`.

## Learn more

- Official website: https://www.phoenixframework.org/
- Guides: https://hexdocs.pm/phoenix/overview.html
- Docs: https://hexdocs.pm/phoenix
- Forum: https://elixirforum.com/c/phoenix-forum
- Source: https://github.com/phoenixframework/phoenix
# alex-portfolio
