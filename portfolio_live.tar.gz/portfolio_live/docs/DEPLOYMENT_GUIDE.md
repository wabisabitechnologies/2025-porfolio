# Deployment Guide (Current Working Process)

> Last updated: November 25, 2025

This document captures the **currently working** deployment process for `portfolio-live`. Follow these steps until Kamal's automated deploys are re-enabled.

---

## 1. Prerequisites

- Docker installed locally (for building + pushing images)
- SSH access to VPS (`ssh contabo`)
- Local Docker registry running on VPS (`38.242.204.55:5000`)
- nginx reverse proxy already configured on VPS
- `.kamal/secrets` populated (at minimum `SECRET_KEY_BASE`)
- Domain entry point: `alex.38.242.204.55.nip.io` (direct IP access is intentionally blocked)

> ✅ Dynamic port assignment: the app container **does not** expose host ports. nginx proxies traffic via the Docker network.

---

## 2. Build Locally (Docker caching)

```bash
cd /home/alekhy/Projects/Personal/alex-portfolio
docker build -t portfolio-live:test .
```

- Most layers are cached; a rebuild usually completes in ~30 seconds unless dependencies changed.

---

## 3. Tag & Push to Local Registry

```bash
docker tag portfolio-live:test 38.242.204.55:5000/portfolio-live:latest
docker push 38.242.204.55:5000/portfolio-live:latest
```

- Only new layers are uploaded to the registry.

---

## 4. Pull & Restart on the VPS

```bash
ssh contabo <<'EOS'
docker pull 38.242.204.55:5000/portfolio-live:latest

docker stop portfolio-live-web-1 || true

docker rm portfolio-live-web-1 || true

docker run -d \
  --name portfolio-live-web-1 \
  --network kamal \
  --label service=portfolio-live \
  -e PHX_HOST=alex.38.242.204.55.nip.io \
  -e PORT=4000 \
  -e SECRET_KEY_BASE=$SECRET_KEY_BASE \
  38.242.204.55:5000/portfolio-live:latest
EOS
```

- Container has **no host port mapping**.
- nginx proxy routes traffic from the domain to the container over the Docker network.

---

## 5. Verify Deployment

```bash
curl -I http://alex.38.242.204.55.nip.io    # should return 200
curl -I http://38.242.204.55               # should fail/444 (blocked intentionally)
```

Optional logs:
```bash
ssh contabo 'docker logs portfolio-live-web-1 --tail 50'
```

---

## 6. Notes & Future Work

- **Kamal buildx issue** (HTTPS vs HTTP registry) still pending. Once fixed, these manual steps can be replaced by `kamal deploy`.
- nginx reverse proxy is the current solution; migrating back to Kamal proxy is optional once the registry issue is resolved.
- Keep `.kamal/secrets` updated with the real `SECRET_KEY_BASE`.
- Domain `alex.38.242.204.55.nip.io` is the supported entry point; direct IP access remains blocked intentionally.

---

## Quick Reference

```bash
# build + push
cd /home/alekhy/Projects/Personal/alex-portfolio
./bin/build-and-push.sh  # optional helper if added

# deploy on VPS
ssh contabo 'docker pull ... && docker stop ... && docker run ...'
```

Track any tweaks in this document so future deploys stay consistent.
