# Deployment Log - Portfolio Live

**Date:** November 25, 2025
**Status:** ✅ App Running (Manual Deployment) | ⚠️ Automated Deployment Pending

## What We Accomplished

### ✅ Completed Steps

1. **Local Docker Build Success**
   - Built Docker image locally: `docker build -t portfolio-live:test .`
   - Build completed successfully (~12 minutes)
   - Verified Dockerfile works correctly

2. **Local Registry Setup**
   - Configured Docker registry on VPS at `38.242.204.55:5000`
   - Registry running in container: `docker run -d -p 5000:5000 --name registry registry:2`
   - Configured Docker on VPS to allow insecure registries

3. **Image Push to Registry**
   - Tagged local image: `docker tag portfolio-live:test 38.242.204.55:5000/portfolio-live:latest`
   - Pushed to local registry: `docker push 38.242.204.55:5000/portfolio-live:latest`
   - Image successfully stored in local registry

4. **Image Pull on VPS**
   - Pulled image on VPS: `docker pull 38.242.204.55:5000/portfolio-live:latest`
   - Image available on server

5. **Manual Container Deployment**
   - Created Docker network: `docker network create kamal`
   - Started container with dynamic port assignment (no host port mapping):
     ```bash
     docker run -d --name portfolio-live-web-1 --network kamal \
       --label service=portfolio-live \
       -e PHX_HOST=alex.38.242.204.55.nip.io \
       -e PORT=4000 \
       -e SECRET_KEY_BASE=<generated-secret> \
       38.242.204.55:5000/portfolio-live:latest
     ```
   - Container accessible only via Docker network (no direct host access)

6. **Nginx Reverse Proxy Setup**
   - Configured nginx to route `alex.38.242.204.55.nip.io` → `portfolio-live-web-1:4000`
   - Blocked direct IP access (returns 444 - connection closed)
   - Domain-only access enforced

7. **App Verification**
   - App responding with HTTP 200 OK via domain
   - Accessible at: `http://alex.38.242.204.55.nip.io` ✅
   - Direct IP access blocked: `http://38.242.204.55` ❌ (connection closed)
   - Phoenix app running successfully

### Configuration Changes Made

1. **deploy.yml Updates**
   - Removed duplicate `config/deploy.yml` (kept root `deploy.yml`)
   - Fixed image name (removed duplicate registry prefix)
   - Configured local registry: `38.242.204.55:5000`
   - Set remote builder: `ssh://alex@38.242.204.55`
   - Removed fixed port mapping (dynamic port assignment)
   - Configured proxy for `alex.38.242.204.55.nip.io`

2. **rule.md Updates**
   - Removed GitHub Actions requirements (manual deployment focus)
   - Updated to reflect local registry workflow
   - Documented remote builder approach
   - Removed references to Docker Hub PAT
   - Added domain-only access requirement
   - Documented dynamic port assignment

3. **SSH Configuration**
   - Cleaned up `~/.ssh/config` to use single `contabo` alias
   - Removed duplicate/conflicting host entries
   - Verified SSH key-based authentication works

4. **Nginx Proxy Configuration**
   - Blocks direct IP access (default server returns 444)
   - Routes domain requests to app container
   - Uses Docker network for container communication
   - No fixed port mapping required

## Current Issues / Pending Work

### ⚠️ Critical: Buildx HTTPS/HTTP Mismatch

**Problem:** Kamal's buildx builder tries to push images using HTTPS, but our local registry only supports HTTP.

**Error:**
```
ERROR: failed to push 38.242.204.55:5000/portfolio-live:...
http: server gave HTTP response to HTTPS client
```

**Impact:**
- `kamal deploy` fails during image push
- `kamal setup` cannot complete automated deployment
- Manual workaround required (build locally, push manually)

**Possible Solutions:**
1. **Configure buildx for insecure registry** (Recommended)
   - Create buildx builder with insecure registry config
   - Modify existing `kamal-local-docker-container` builder
   - Requires Docker daemon configuration

2. **Use remote builder properly**
   - Ensure remote builder builds directly on VPS
   - Avoids local buildx push issue
   - May require buildx configuration on VPS

3. **Set up TLS for local registry**
   - Configure registry with SSL certificates
   - More complex but proper solution
   - Requires certificate management

### ⚠️ Pending: Kamal Proxy Integration

**Status:** Using nginx as workaround

**Current Setup:**
- Nginx reverse proxy working correctly
- Domain routing functional
- IP access blocked

**Future Work:**
- Fix Kamal proxy configuration format
- Migrate from nginx to Kamal proxy when buildx issue resolved
- Or keep nginx if it works well

### ⚠️ Pending: SECRET_KEY_BASE in Secrets File

**Status:** Placeholder value in `.kamal/secrets`

**Action Required:**
- Generate proper secret: `mix phx.gen.secret`
- Update `.kamal/secrets` with real value
- Current manual deployment uses generated secret directly

**Generated Secret (for reference):**
```
A85ZBWwC7WRUYVo0OS5j/+hj7uM1CU8myS0ynd5iHJ+jXR+/y1tgUtYylc/6cKjV
```

## Manual Deployment Workflow (Current)

Since automated deployment is blocked, use this workflow:

1. **Build locally:**
   ```bash
   docker build -t portfolio-live:test .
   ```

2. **Tag and push:**
   ```bash
   docker tag portfolio-live:test 38.242.204.55:5000/portfolio-live:latest
   docker push 38.242.204.55:5000/portfolio-live:latest
   ```

3. **Pull on VPS:**
   ```bash
   ssh contabo 'docker pull 38.242.204.55:5000/portfolio-live:latest'
   ```

4. **Restart container (dynamic ports, no host mapping):**
   ```bash
   ssh contabo 'docker rm -f portfolio-live-web-1; docker run -d --name portfolio-live-web-1 --network kamal --label service=portfolio-live -e PHX_HOST=alex.38.242.204.55.nip.io -e PORT=4000 -e SECRET_KEY_BASE=<secret> 38.242.204.55:5000/portfolio-live:latest'
   ```

**Note:** Container has no host port mapping - accessible only via nginx proxy on domain.

## Next Steps (Priority Order)

1. **Fix buildx insecure registry** - Enable automated deployments
2. **Complete Kamal setup** - Migrate from nginx to Kamal proxy (optional)
3. **Update secrets file** - Add real SECRET_KEY_BASE
4. **Test full deployment** - Verify `kamal deploy` works end-to-end
5. **Document final workflow** - Update rule.md with working process

## Infrastructure Details

- **VPS:** Contabo at `38.242.204.55`
- **SSH User:** `alex`
- **SSH Alias:** `contabo` (in `~/.ssh/config`)
- **Registry:** Local Docker registry at `38.242.204.55:5000`
- **Network:** Docker network `kamal`
- **Domain:** `alex.38.242.204.55.nip.io` ✅ Working
- **Port Assignment:** Dynamic (no fixed port mapping)
- **IP Access:** Blocked (only domain access allowed)
- **Proxy:** Nginx reverse proxy (Kamal proxy pending)

## Commands Reference

```bash
# Check app status
ssh contabo 'docker ps | grep portfolio'
ssh contabo 'docker logs portfolio-live-web-1'

# Test domain access
curl -I http://alex.38.242.204.55.nip.io

# Test IP blocking (should fail)
curl -I http://38.242.204.55

# Kamal commands (when buildx fixed)
kamal deploy -c deploy.yml
kamal app details -c deploy.yml
kamal app logs -c deploy.yml
```

---

**Last Updated:** November 25, 2025
**Deployed By:** Manual process
**App Status:** ✅ Running via domain `alex.38.242.204.55.nip.io`
**Port Configuration:** Dynamic (no fixed port mapping)
**IP Access:** Blocked (domain-only access)
