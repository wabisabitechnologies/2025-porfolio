SSH Setup helper

This folder contains a small helper script to safely install SSH private/public keys into `~/.ssh`, set secure permissions, and add a Host entry to your `~/.ssh/config`.

Files

- `ssh-setup.sh` : Script that copies keys, backs up `~/.ssh/config`, appends a Host entry, and can add the key to `ssh-agent`.

Quick examples

1) Use keys already in `~/.ssh` (adds host alias `contabo` for your VPS):

```bash
cd $(git rev-parse --show-toplevel) || true
bash config/ssh-setup.sh --alias contabo --hostname 38.242.204.55 --user alex
```

2) Copy keys from a folder (e.g. `~/drft`) and register the host, adding the key to the agent:

```bash
bash config/ssh-setup.sh --key-dir ~/drft --alias vps --hostname 38.242.204.55 --user alex --add-agent
```

Safety notes

- The script will back up your existing `~/.ssh/config` to `~/.ssh/config.bak.<timestamp>` before modifying it.
- It will set `600` on private keys and `644` on public keys.
- Review the resulting `~/.ssh/config` and remove duplicate or unwanted Host blocks if necessary.
- The script does not print private key contents or upload keys anywhere.

Reverting

If something goes wrong open the backup file (e.g. `~/.ssh/config.bak.123456789`) and restore it:

```bash
cp ~/.ssh/config.bak.123456789 ~/.ssh/config
chmod 600 ~/.ssh/config
```

If you want assistance running the script or customizing the Host alias, tell me which alias/hostname you prefer and I can update the script or the README accordingly.