#!/usr/bin/env bash
set -euo pipefail

# Safe SSH key installer + ssh config helper
# - Copies a private key (and optional public key) into ~/.ssh
# - Sets safe permissions
# - Backs up ~/.ssh/config and appends a Host entry (if not present)
# - Optionally adds the key to the ssh-agent

usage() {
  cat <<EOF
Usage: $0 [--key-dir DIR] [--private PATH] [--pub PATH] [--alias ALIAS] [--hostname HOST] [--user USER] [--add-agent] [--yes]

Examples:
  # Use keys already in ~/.ssh and add a host entry for contabo
  $0 --alias contabo --hostname 38.242.204.55 --user alex

  # Copy keys from a folder and register a host
  $0 --key-dir ~/drft --alias vps --hostname 38.242.204.55 --user alex --add-agent
EOF
}

KEY_DIR="${HOME}/drft"
PRIVATE_PATH=""
PUB_PATH=""
ALIAS="vps"
HOSTNAME=""
USER_NAME="alex"
ADD_AGENT=0
AUTO_YES=0

while [[ $# -gt 0 ]]; do
  case $1 in
    --key-dir) KEY_DIR="$2"; shift 2;;
    --private) PRIVATE_PATH="$2"; shift 2;;
    --pub) PUB_PATH="$2"; shift 2;;
    --alias) ALIAS="$2"; shift 2;;
    --hostname) HOSTNAME="$2"; shift 2;;
    --user) USER_NAME="$2"; shift 2;;
    --add-agent) ADD_AGENT=1; shift;;
    --yes|-y) AUTO_YES=1; shift;;
    --help|-h) usage; exit 0;;
    *) echo "Unknown arg: $1"; usage; exit 1;;
  esac
done

if [[ -z "$HOSTNAME" ]]; then
  echo "Error: --hostname is required (IP or DNS of target host)." >&2
  usage
  exit 2
fi

mkdir -p -- "${HOME}/.ssh"
chmod 700 "${HOME}/.ssh"

# Helper: find a private key in a directory (non .pub)
find_private_in_dir() {
  local dir="$1"
  # prefer files with 'vps' or '*.pem', else id_* but not *.pub
  local candidate
  candidate=$(find "$dir" -maxdepth 1 -type f \( -name "*vps*" -o -name "*.pem" -o -name "id_*" \) ! -name "*.pub" 2>/dev/null | head -n1 || true)
  echo "$candidate"
}

# Determine private key to use
if [[ -n "$PRIVATE_PATH" ]]; then
  if [[ ! -f "$PRIVATE_PATH" ]]; then
    echo "Private key "$PRIVATE_PATH" not found." >&2
    exit 3
  fi
  src_priv="$PRIVATE_PATH"
else
  # try ~/.ssh first
  preferred="$HOME/.ssh/$ALIAS"
  if [[ -f "$preferred" ]]; then
    src_priv="$preferred"
  else
    found="$(find_private_in_dir "$KEY_DIR")"
    if [[ -n "$found" ]]; then
      src_priv="$found"
    else
      # fallback: first private key in ~/.ssh (not *.pub)
      found_local=$(find "$HOME/.ssh" -maxdepth 1 -type f ! -name "*.pub" ! -name "known_hosts" ! -name "authorized_keys" 2>/dev/null | head -n1 || true)
      if [[ -n "$found_local" ]]; then
        src_priv="$found_local"
      else
        echo "No private key found in ~/.ssh or $KEY_DIR. Provide --private or place keys in $KEY_DIR" >&2
        exit 4
      fi
    fi
  fi
fi

priv_basename=$(basename "$src_priv")
dest_priv="$HOME/.ssh/$priv_basename"

# determine public key
if [[ -n "$PUB_PATH" ]]; then
  if [[ ! -f "$PUB_PATH" ]]; then
    echo "Public key "$PUB_PATH" not found." >&2
    exit 5
  fi
  src_pub="$PUB_PATH"
else
  # try same name + .pub or any .pub in same dir
  maybe_pub="${src_priv}.pub"
  if [[ -f "$maybe_pub" ]]; then
    src_pub="$maybe_pub"
  else
    # find any .pub in src dir
    dir_of_priv="$(dirname "$src_priv")"
    found_pub=$(find "$dir_of_priv" -maxdepth 1 -type f -name "*.pub" | head -n1 || true)
    if [[ -n "$found_pub" ]]; then
      src_pub="$found_pub"
    else
      src_pub=""
    fi
  fi
fi

echo "Using private key: $src_priv"
if [[ -n "$src_pub" ]]; then
  echo "Using public key: $src_pub"
fi

if [[ "$AUTO_YES" -ne 1 ]]; then
  read -r -p "Proceed to copy keys to ~/.ssh and update ~/.ssh/config for host alias '$ALIAS' (y/N)? " ans
  case "$ans" in
    [yY][eE][sS]|[yY]) ;; 
    *) echo "Aborted by user."; exit 0;;
  esac
fi

# Copy private key if needed
if [[ "$src_priv" != "$dest_priv" ]]; then
  echo "Copying private key to $dest_priv"
  cp -- "$src_priv" "$dest_priv"
fi
chmod 600 "$dest_priv"

# Copy public key if present
if [[ -n "$src_pub" ]]; then
  pub_basename=$(basename "$src_pub")
  dest_pub="$HOME/.ssh/$pub_basename"
  if [[ "$src_pub" != "$dest_pub" ]]; then
    echo "Copying public key to $dest_pub"
    cp -- "$src_pub" "$dest_pub" || true
  fi
  chmod 644 "$dest_pub" || true
fi

# Backup existing config
CFG="$HOME/.ssh/config"
if [[ -f "$CFG" ]]; then
  bak="$CFG.bak.$(date +%s)"
  echo "Backing up existing $CFG -> $bak"
  cp -- "$CFG" "$bak"
fi

# Append a Host block if alias not already present
if grep -E "^Host[[:space:]]+$ALIAS(\s+|$)" -q "$CFG" 2>/dev/null || (test -f "$CFG" && grep -E "^Host[[:space:]]+$ALIAS(\s+|$)" -q <(cat "$CFG") 2>/dev/null); then
  echo "A Host entry for '$ALIAS' already exists in $CFG. Appending a new entry with a different alias is safer."
  echo "You can edit $CFG to adjust which IdentityFile the host uses if needed."
fi

cat >> "$CFG" <<EOF

# Added by ssh-setup.sh on $(date --iso-8601=seconds)
Host $ALIAS
  HostName $HOSTNAME
  User $USER_NAME
  IdentityFile $dest_priv
  IdentitiesOnly yes
  AddKeysToAgent yes
  Port 22
EOF

chmod 600 "$CFG"

if [[ "$ADD_AGENT" -eq 1 ]]; then
  # Try to add to ssh-agent
  if ssh-add -l >/dev/null 2>&1; then
    echo "Adding $dest_priv to existing ssh-agent"
    ssh-add "$dest_priv" || true
  else
    # try to start an agent
    echo "Starting ssh-agent and adding key"
    eval "$(ssh-agent -s)" >/dev/null 2>&1 || true
    ssh-add "$dest_priv" || true
  fi
fi

cat <<EOF
Done.
- Private key: $dest_priv (mode 600)
- ssh config updated: $CFG

To test the connection:
  ssh -v $ALIAS
Or explicitly:
  ssh -i $dest_priv $USER_NAME@$HOSTNAME

If you want to revert config changes, a backup was made to: $bak
EOF
