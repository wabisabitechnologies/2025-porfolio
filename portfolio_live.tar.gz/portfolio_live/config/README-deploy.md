Deploy hook & installation

Goal

Make pushing to the VPS remote automatically update a working copy and run an optional deploy script.

Files

- `config/deploy/post-receive.sample` — Minimal, safe `post-receive` hook for the bare git repo on the VPS. Copy it to the VPS and make it executable.

Quick overview (what you need to do on the VPS)

1) Create a bare repo on the VPS (one-time):

```bash
# on VPS (as user alex)
mkdir -p ~/repos
cd ~/repos
git init --bare app.git
```

2) Install the hook:

- Copy `config/deploy/post-receive.sample` to `/home/alex/repos/app.git/hooks/post-receive` on the VPS (use `scp` or paste it into an editor).
- Make it executable:

```bash
chmod +x /home/alex/repos/app.git/hooks/post-receive
```

3) Create a working directory where the app will be checked out (match the `WORK_TREE` in the hook):

```bash
mkdir -p /home/alex/www/app
chown -R alex:alex /home/alex/www/app
```

4) (Optional) Add a `deploy.sh` inside `/home/alex/www/app` that builds/restarts your app. Example `deploy.sh` for Elixir/Phoenix might:

```bash
#!/usr/bin/env bash
set -euo pipefail
# This is just an example. Customize for your app.
cd "$(dirname "$0")"
# fetch deps, compile, build assets, restart service
mix deps.get
MIX_ENV=prod mix compile
# run any asset build or release steps
# systemctl restart myapp.service
```

Make sure `deploy.sh` is executable: `chmod +x /home/alex/www/app/deploy.sh`.

5) Ensure your local repo has the VPS remote and push:

```bash
# from your local repo
git remote add vps ssh://alex@38.242.204.55:/home/alex/repos/app.git
# push main (or whichever branch the hook watches)
git push vps main
```

What the hook does

- The sample `post-receive` only reacts to pushes to `refs/heads/main` by default. It checks out the pushed commit to the configured `WORK_TREE` and runs `deploy.sh` if present and executable.
- It logs actions to `/var/log/git-deploy.log`. Adjust paths, permissions and the branch name to match your workflow.

Troubleshooting

- If push succeeds but nothing appears in the `WORK_TREE`, check `hooks/post-receive` permissions and the hook log file (`/var/log/git-deploy.log`).
- If the hook fails due to permissions: ensure the user who owns the bare repo (`alex`) can write to the `WORK_TREE` and run the deploy script.
- If the deploy script needs services to be restarted, ensure it either runs `systemctl --user` commands or the system service is configured to be restarted by a privileged user (use sudo with appropriate permissions if necessary).

Auto-push from local

If you want commits to automatically push to the VPS, create a local hook `./git/hooks/post-commit` in your working repo with:

```bash
#!/usr/bin/env bash
# push current branch to vps remote
branch=$(git rev-parse --abbrev-ref HEAD)
git push vps "$branch"
```

Make it executable: `chmod +x .git/hooks/post-commit`.

This will push every commit; use carefully (you may prefer manual pushes or CI).

If you want me to:
- Write a more advanced `post-receive` that runs `mix`/`npm`/build steps and restarts a systemd service, tell me your deploy directory and how you start the app (systemd service name or other),
- Or remotely install the hook (I cannot ssh to your VPS from here, but I can produce exact commands you can run),
- Or set up a safe local post-commit hook to auto-push, and test it interactively.

Tell me which option you want and I'll prepare the files/commands accordingly.

---

Kamal (recommended) — bootstrap and deploy from your local machine

This repo already contains a `deploy.yml` at the project root and `config/deploy.yml` tuned for your VPS (`38.242.204.55`). Use Kamal to bootstrap the server (installs Docker, configures proxy) and deploy the app with zero downtime.

Quick commands (run from the project root):

1) Install Kamal locally (uses Bundler):

```bash
bundle init || true
bundle add kamal
bundle install
bundle exec kamal version
```

2) Prepare secrets (do NOT commit `.kamal/secrets`):

```bash
# copy sample and edit
cp .kamal/secrets.sample .kamal/secrets
# edit .kamal/secrets and fill SECRET_KEY_BASE and KAMAL_REGISTRY_PASSWORD
```

3) Ensure SSH key availability for Kamal:

- If you already have `~/.ssh/vps-contabo` (private key) on your machine, run:

```bash
export KAMAL_SSH_KEY="$HOME/.ssh/vps-contabo"
```

- Or leave unset and provide `VPS_SSH_PRIVATE_KEY` in `.kamal/secrets` (less recommended).

4) Bootstrap the server (this will install Docker, create Kamal user, and ready the server):

```bash
bundle exec kamal server bootstrap
```

5) Deploy (build image locally, push to registry, and deploy to your VPS):

```bash
bundle exec kamal deploy
```

6) Useful commands:

```bash
bundle exec kamal logs -f        # follow app logs
bundle exec kamal console        # open an iex console on the server
bundle exec kamal rollback       # rollback to previous release
```

Notes & troubleshooting

- The repo `deploy.yml` already uses image `wabisabitech/portfolio-live` and the Contabo IP. Update `registry.username`/`password` in `.kamal/secrets` if you use Docker Hub, or change `registry.server` for GHCR.
- Kamal expects a health endpoint (default `/up`). If your Phoenix app doesn't expose `/up`, either add a basic plug/route that returns 200 or configure Kamal health checks in `deploy.yml`.
- If `bundle exec kamal server bootstrap` fails with SSH errors, verify you can `ssh alex@38.242.204.55` and that `KAMAL_SSH_KEY` points to a usable private key (or `.ssh/vps-contabo` exists).
- The `config/docker-entrypoint` added in this repo runs migrations before starting the release; update the migration eval (MyApp.Release.migrate) to match your app module if needed.

If you want, I can:
- Edit `config/docker-entrypoint` to use your actual release module name (e.g., `PortfolioLive.Release.migrate`). Tell me the app module name (check `mix.exs` `:app` or `application` module).
- Prepare exact `scp` + `ssh` commands to copy hooks or install Kamal remotely.
