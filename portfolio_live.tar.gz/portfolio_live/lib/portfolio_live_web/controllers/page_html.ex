defmodule PortfolioLiveWeb.PageHTML do
  use PortfolioLiveWeb, :html

  embed_templates "page_html/*"
end
