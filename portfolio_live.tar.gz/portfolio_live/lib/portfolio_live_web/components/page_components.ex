defmodule PortfolioLiveWeb.PageComponents do
  use Phoenix.Component

  use Phoenix.VerifiedRoutes,
    endpoint: PortfolioLiveWeb.Endpoint,
    router: PortfolioLiveWeb.Router,
    statics: PortfolioLiveWeb.static_paths()

  alias PortfolioLive.Availability

  @icons %{
    "sparkles" =>
      "M12 3v2m0 14v2m9-9h-2M5 12H3m15.364 6.364l-1.414-1.414M6.05 6.05 4.636 4.636m12.728 0-1.414 1.414M6.05 17.95l-1.414 1.414M8 12a4 4 0 1 0 8 0 4 4 0 0 0-8 0Z",
    "arrow_up_right" => "M7 17 17 7m0 0H9m8 0v8",
    "search" => "m21 21-4.35-4.35M11 19a8 8 0 1 1 0-16 8 8 0 0 1 0 16Z",
    "dot" => "M12 12m-5 0a5 5 0 1 0 10 0 5 5 0 1 0-10 0"
  }

  @case_study_placeholders [
    "https://framerusercontent.com/images/zf6LxLgW17Coi1PMuGEvhAMMtXo.webp?width=1600",
    "https://framerusercontent.com/images/fqyjCDbGm7R1AekelRPdY1744.webp?width=1600"
  ]

  attr :profile, :map, required: true

  def profile_identity(assigns) do
    assigns =
      assign(assigns, :availability_text, Availability.format(assigns.profile))

    ~H"""
    <header>
      <.link navigate={~p"/"} class="flex items-center gap-3 text-left">
        <img
          src={@profile.profile_photo}
          alt={"Portrait of #{@profile.name}"}
          class="h-12 w-12 rounded-full object-cover shadow-lg ring-4 ring-white"
        />
        <div>
          <p class="text-lg font-semibold text-slate-900"><%= @profile.name %></p>
          <p class="text-sm text-emerald-500 font-medium flex items-center gap-2">
            <span class="inline-flex h-2 w-2 rounded-full bg-emerald-500"></span>
            <%= @availability_text %>
          </p>
        </div>
      </.link>
    </header>
    """
  end

  attr :profile, :map, required: true
  attr :navigation, :list, default: []
  attr :active_key, :string, default: nil

  def page_header(assigns) do
    ~H"""
    <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
      <.profile_identity profile={@profile} />
      <.top_nav
        navigation={@navigation}
        active_key={@active_key}
        class="w-full justify-start md:w-auto md:justify-end"
      />
    </div>
    """
  end

  attr :name, :string, required: true
  attr :class, :string, default: "h-4 w-4"

  def lucide_icon(assigns) do
    assigns = assign(assigns, :path, Map.fetch!(@icons, assigns.name))

    ~H"""
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
      class={@class}
    >
      <path d={@path} />
    </svg>
    """
  end

  attr :navigation, :list, default: []
  attr :active_key, :string, default: nil
  attr :class, :any, default: ""
  slot :search

  def top_nav(assigns) do
    ~H"""
    <nav class={["flex items-center gap-6 text-sm font-medium", @class]}>
      <%= for item <- @navigation do %>
        <% key = item[:key] || item["key"] %>
        <% disabled = Map.get(item, :disabled, Map.get(item, "disabled", false)) %>
        <.link
          href={item[:href] || item["href"]}
          class={[
            "pb-2 transition",
            cond do
              disabled -> "text-slate-300 cursor-not-allowed"
              key && to_string(key) == to_string(@active_key) -> "text-slate-900"
              true -> "text-slate-400 hover:text-slate-900"
            end
          ]}
          aria-disabled={disabled}
        >
          <span class="inline-flex items-center gap-2">
            <%= if key && to_string(key) == to_string(@active_key) do %>
              <span class="h-2 w-2 rounded-full bg-slate-900"></span>
            <% end %>
            <%= item[:label] || item["label"] %>
          </span>
        </.link>
      <% end %>
      <%= if Enum.any?(@search) do %>
        <%= render_slot(@search) %>
      <% else %>
        <button type="button" class="ml-auto text-slate-400 hover:text-slate-900">
          <span class="sr-only">Search</span>
          <.lucide_icon name="search" class="h-4 w-4" />
        </button>
      <% end %>
    </nav>
    """
  end

  attr :cta, :list, default: []

  def cta_buttons(assigns) do
    ~H"""
    <div class="flex flex-wrap gap-4">
      <%= for {cta, idx} <- Enum.with_index(@cta) do %>
        <.link
          href={cta[:href] || cta["href"]}
          class={[
            "inline-flex items-center gap-2 rounded-full px-5 py-3 text-sm font-medium transition",
            if(idx == 0,
              do: "bg-slate-900 text-white hover:bg-slate-800",
              else: "bg-white text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50"
            )
          ]}
        >
          <%= if idx == 0 do %>
            <.lucide_icon name="sparkles" class="h-4 w-4" />
          <% else %>
            <span class="inline-flex h-6 w-6 items-center justify-center rounded-full bg-slate-900 text-white">
              <.lucide_icon name="arrow_up_right" class="h-3.5 w-3.5" />
            </span>
          <% end %>
          <%= cta[:label] || cta["label"] %>
        </.link>
      <% end %>
    </div>
    """
  end

  attr :study, :map, required: true
  attr :id, :string, default: nil

  def case_study_card(assigns) do
    assigns = assign(assigns, :image, case_study_image(assigns.study))

    ~H"""
    <.link
      id={@id}
      href={"/case-studies/" <> @study.slug}
      class="block rounded-[24px] border border-slate-200 bg-white"
    >
      <div class="grid gap-6 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)] lg:items-center">
        <div class="p-6 sm:p-7 lg:p-8">
          <p class="text-xs uppercase tracking-[0.35em] text-slate-400">
            <%= @study.category %>
          </p>
          <h2 class="text-[1.75rem] font-semibold leading-snug text-slate-900">
            <%= @study.title %>
          </h2>
          <p class="text-base text-slate-600">
            <%= @study.summary %>
          </p>

          <div class="flex flex-wrap gap-4 text-sm">
            <%= for stat <- Enum.take(@study.stats, 2) do %>
              <div>
                <p class="text-xs uppercase tracking-[0.25em] text-slate-400">
                  <%= stat[:label] || stat["label"] %>
                </p>
                <p class="text-lg font-semibold text-slate-900">
                  <%= stat[:value] || stat["value"] %>
                </p>
              </div>
            <% end %>
          </div>

          <div class="inline-flex items-center gap-2 text-sm font-medium text-slate-900">
            View details <.lucide_icon name="arrow_up_right" class="h-4 w-4" />
          </div>
        </div>

        <div class="rounded-2xl border border-slate-200 bg-slate-50">
          <img
            src={@image}
            alt={"Preview of #{@study.title}"}
            class="aspect-[3/2] w-full rounded-2xl object-cover"
            loading="lazy"
            decoding="async"
          />
        </div>
      </div>
    </.link>
    """
  end

  attr :tils, :list, default: []

  def til_list(assigns) do
    ~H"""
    <div class="space-y-3">
      <%= for til <- @tils do %>
        <article class="rounded-[20px] border border-slate-200 bg-white p-5">
          <div class="flex items-center justify-between text-xs text-slate-400 uppercase tracking-[0.3em]">
            <span>TIL</span>
            <time datetime={Date.to_iso8601(til.published_at)}>
              <%= Calendar.strftime(til.published_at, "%b %d, %Y") %>
            </time>
          </div>
          <h3 class="mt-3 text-base font-semibold text-slate-900"><%= til.title %></h3>
          <p class="mt-1 text-sm text-slate-500"><%= til.summary %></p>
          <div class="mt-3 flex flex-wrap gap-2">
            <%= for tag <- til.tags do %>
              <span class="rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-600">
                <%= tag %>
              </span>
            <% end %>
          </div>
        </article>
      <% end %>
    </div>
    """
  end

  attr :links, :list, default: []

  def sidebar(assigns) do
    ~H"""
    <aside class="space-y-6 rounded-[24px] border border-slate-200 bg-white p-6">
      <%= for link <- @links do %>
        <div>
          <p class="text-xs font-semibold uppercase tracking-[0.3em] text-slate-400 mb-2">
            <%= link[:label] || link["label"] %>
          </p>
          <%= if items = link[:items] || link["items"] do %>
            <ul class="space-y-1 text-sm text-slate-600">
              <%= for item <- items do %>
                <li>
                  <%= render_sidebar_item(item) %>
                </li>
              <% end %>
            </ul>
          <% else %>
            <.link href={link[:href] || link["href"]} class="text-sm font-medium text-slate-900">
              <%= link[:label] || link["label"] %>
            </.link>
          <% end %>
        </div>
      <% end %>
    </aside>
    """
  end

  defp case_study_image(study) do
    image =
      if is_map(study) do
        Map.get(study, :hero_image) || Map.get(study, "hero_image")
      end

    slug =
      if is_map(study) do
        Map.get(study, :slug) || Map.get(study, "slug")
      end

    image ||
      Enum.at(
        @case_study_placeholders,
        :erlang.phash2(slug || 0, length(@case_study_placeholders)),
        hd(@case_study_placeholders)
      )
  end

  defp render_sidebar_item(item) when is_map(item) do
    label = item[:label] || item["label"]
    href = item[:href] || item["href"]

    if href do
      assigns = %{label: label, href: href}

      ~H"""
      <.link href={@href} class="text-slate-900 hover:underline">
        <%= @label %>
      </.link>
      """
    else
      label
    end
  end

  defp render_sidebar_item(item), do: item
end
