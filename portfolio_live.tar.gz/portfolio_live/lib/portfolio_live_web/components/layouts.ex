defmodule PortfolioLiveWeb.Layouts do
  use PortfolioLiveWeb, :html

  embed_templates "layouts/*"
end
