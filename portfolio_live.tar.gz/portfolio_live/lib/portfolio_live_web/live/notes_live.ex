defmodule PortfolioLiveWeb.NotesLive do
  use PortfolioLiveWeb, :live_view

  alias PortfolioLive.Content

  def mount(_params, _session, socket) do
    page = Content.notes_page()
    categories = Content.note_categories()
    grouped = Content.notes_grouped()
    active = List.first(categories) || "Product"

    socket =
      socket
      |> assign(:page, page)
      |> assign(:profile, Content.homepage())
      |> assign(:navigation, Content.navigation())
      |> assign(:categories, categories)
      |> assign(:notes_grouped, grouped)
      |> assign(:active_category, active)
      |> assign(:active_notes, Map.get(grouped, active, []))

    {:ok, socket}
  end

  def handle_event("set-category", %{"filter" => category}, socket) do
    notes = Map.get(socket.assigns.notes_grouped, category, [])
    {:noreply, assign(socket, active_category: category, active_notes: notes)}
  end

  def render(assigns) do
    ~H"""
    <div class="min-h-screen bg-white text-slate-900">
      <div class="mx-auto max-w-6xl space-y-10 px-6 pb-16 pt-10 sm:px-8 lg:px-10">
        <.page_header profile={@profile} navigation={@navigation} active_key="notes" />

        <div class="grid gap-10 lg:grid-cols-[minmax(0,1.6fr)_minmax(0,0.7fr)] lg:items-start">
          <section class="space-y-8">
            <div class="space-y-3">
              <p class="text-xs uppercase tracking-[0.3em] text-slate-400">Notes</p>
              <h1 class="text-4xl font-semibold leading-snug"><%= @page.title %></h1>
              <p class="text-base text-slate-500 max-w-3xl"><%= @page.summary %></p>
            </div>

            <div class="flex flex-wrap gap-3 text-sm font-medium">
              <%= for category <- @categories do %>
                <button
                  type="button"
                  phx-click="set-category"
                  phx-value-filter={category}
                  class={[
                    "inline-flex items-center gap-2 rounded-full border px-4 py-2 transition",
                    if(category == @active_category,
                      do: "border-slate-900 text-slate-900",
                      else: "border-slate-200 text-slate-400 hover:text-slate-900"
                    )
                  ]}
                >
                  <%= if category == @active_category do %>
                    <span class="inline-flex h-2 w-2 rounded-full bg-slate-900"></span>
                  <% end %>
                  <%= category %>
                </button>
              <% end %>
            </div>

            <div class="space-y-6">
              <%= if @active_notes == [] do %>
                <p class="text-sm text-slate-500">No notes in this category yet.</p>
              <% else %>
                <%= for note <- @active_notes do %>
                  <article
                    id={"note-#{note.slug}"}
                    class="rounded-[20px] border border-slate-200 bg-white p-5 scroll-mt-24"
                  >
                    <div class="flex items-center justify-between text-xs uppercase tracking-[0.3em] text-slate-400">
                      <span><%= note.category %></span>
                      <time datetime={Date.to_iso8601(note.published_at)}>
                        <%= Calendar.strftime(note.published_at, "%b %d, %Y") %>
                      </time>
                    </div>
                    <h2 class="mt-3 text-2xl font-semibold text-slate-900"><%= note.title %></h2>
                    <p class="mt-2 text-base text-slate-500"><%= note.summary %></p>
                    <div class="mt-3 flex flex-wrap gap-2 text-xs text-slate-500">
                      <%= for tag <- note.tags do %>
                        <span class="rounded-full bg-slate-100 px-3 py-1 text-slate-600">
                          <%= tag %>
                        </span>
                      <% end %>
                    </div>
                  </article>
                <% end %>
              <% end %>
            </div>
          </section>

          <div class="space-y-8 self-start lg:sticky lg:top-24">
            <.sidebar links={@page.sidebar_links} />
          </div>
        </div>
      </div>
    </div>
    """
  end
end
