defmodule PortfolioLiveWeb.AboutLive do
  use PortfolioLiveWeb, :live_view

  alias PortfolioLive.Content

  def mount(_params, _session, socket) do
    page = Content.about_page()

    socket =
      socket
      |> assign(:page, page)
      |> assign(:profile, Content.homepage())
      |> assign(:navigation, Content.navigation())

    {:ok, socket}
  end

  def render(assigns) do
    ~H"""
    <div class="min-h-screen bg-white text-slate-900">
      <div class="mx-auto max-w-6xl space-y-10 px-6 pb-16 pt-10 sm:px-8 lg:px-10">
        <.page_header profile={@profile} navigation={@navigation} active_key="about" />

        <div class="grid gap-10 lg:grid-cols-[minmax(0,1.6fr)_minmax(0,0.7fr)] lg:items-start">
          <section class="space-y-8">
            <div class="space-y-3">
              <p class="text-xs uppercase tracking-[0.3em] text-slate-400">Profile</p>
              <h1 class="text-4xl font-semibold leading-snug"><%= @page.title %></h1>
              <p class="text-base text-slate-500 max-w-3xl"><%= @page.summary %></p>
            </div>
            <div class="prose prose-slate max-w-none text-slate-600">
              <%= raw(@page.body) %>
            </div>
          </section>

          <div class="space-y-8 self-start lg:sticky lg:top-24">
            <.sidebar links={@page.sidebar_links} />
          </div>
        </div>
      </div>
    </div>
    """
  end
end
