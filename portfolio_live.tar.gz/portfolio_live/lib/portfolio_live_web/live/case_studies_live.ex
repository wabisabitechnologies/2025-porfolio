defmodule PortfolioLiveWeb.CaseStudiesLive do
  use PortfolioLiveWeb, :live_view

  alias PortfolioLive.Content

  def mount(_params, _session, socket) do
    page = Content.case_studies_page()
    case_studies = Content.case_studies()

    socket =
      socket
      |> assign(:page, page)
      |> assign(:profile, Content.homepage())
      |> assign(:all_case_studies, case_studies)
      |> assign(:navigation, Content.navigation())
      |> assign(:category_filter, nil)
      |> assign(:work_type_filter, "All")

    {:ok, socket}
  end

  def handle_params(params, _uri, socket) do
    category = Map.get(params, "category")
    work_type = Map.get(params, "work_type", "All")

    socket =
      socket
      |> assign(:category_filter, category)
      |> assign(:work_type_filter, work_type)
      |> assign_filtered_case_studies()

    {:noreply, socket}
  end

  def handle_event("set-work-type", %{"work-type" => work_type}, socket) do
    params = %{"work_type" => work_type}

    params =
      if socket.assigns.category_filter,
        do: Map.put(params, "category", socket.assigns.category_filter),
        else: params

    {:noreply, push_patch(socket, to: ~p"/case-studies?#{params}")}
  end

  def render(assigns) do
    ~H"""
    <div class="min-h-screen bg-white text-slate-900">
      <div class="mx-auto max-w-6xl px-6 pb-16 pt-10 sm:px-8 lg:px-10 space-y-12">
        <.page_header profile={@profile} navigation={@navigation} active_key="case_studies" />

        <div class="grid gap-10 lg:grid-cols-[minmax(0,1.6fr)_minmax(0,0.7fr)] lg:items-start">
          <section class="space-y-10">
            <div class="space-y-3">
              <p class="text-xs uppercase tracking-[0.3em] text-slate-400">Case Studies</p>
              <h1 class="text-4xl font-semibold leading-snug"><%= @page.title %></h1>
              <p class="text-base text-slate-500 max-w-3xl"><%= @page.summary %></p>
            </div>

            <%= if @category_filter do %>
              <div class="flex flex-wrap gap-3 text-sm font-medium border-b border-slate-200">
                <%= for work_type <- ["All", "For Business Owners", "For Practitioners", "Platform & Infrastructure"] do %>
                  <button
                    type="button"
                    phx-click="set-work-type"
                    phx-value-work-type={work_type}
                    class={[
                      "px-4 py-2 transition relative",
                      if(work_type == @work_type_filter,
                        do: "text-slate-900 font-medium",
                        else: "text-slate-500 hover:text-slate-900"
                      )
                    ]}
                  >
                    <%= work_type %>
                    <%= if work_type == @work_type_filter do %>
                      <span class="absolute bottom-0 left-0 right-0 h-0.5 bg-slate-900"></span>
                    <% end %>
                  </button>
                <% end %>
              </div>

              <%= if @work_type_filter == "All" do %>
                <%= for {work_type, studies} <- @grouped_case_studies do %>
                  <div class="space-y-6">
                    <h2 class="text-2xl font-semibold text-slate-900"><%= work_type %></h2>
                    <div class="space-y-8">
                      <%= for study <- studies do %>
                        <.case_study_card id={"case-#{study.slug}"} study={study} />
                      <% end %>
                    </div>
                  </div>
                <% end %>
              <% else %>
                <div class="space-y-8">
                  <%= for study <- @filtered_case_studies do %>
                    <.case_study_card id={"case-#{study.slug}"} study={study} />
                  <% end %>
                </div>
              <% end %>
            <% else %>
              <div class="space-y-8">
                <%= for study <- @filtered_case_studies do %>
                  <.case_study_card id={"case-#{study.slug}"} study={study} />
                <% end %>
              </div>
            <% end %>
          </section>

          <div class="space-y-8 self-start lg:sticky lg:top-24">
            <.sidebar links={@page.sidebar_links} />
          </div>
        </div>
      </div>
    </div>
    """
  end

  defp assign_filtered_case_studies(socket) do
    case_studies = socket.assigns.all_case_studies
    category_filter = socket.assigns.category_filter
    work_type_filter = socket.assigns.work_type_filter

    # Filter by category if specified
    filtered =
      if category_filter do
        Enum.filter(case_studies, fn study ->
          Map.get(study, :category) == category_filter
        end)
      else
        case_studies
      end

    # If we're viewing a specific category, group by work_type
    if category_filter do
      work_types = ["For Business Owners", "For Practitioners", "Platform & Infrastructure"]

      grouped =
        Enum.map(work_types, fn work_type ->
          studies =
            Enum.filter(filtered, fn study ->
              Map.get(study, :work_type) == work_type
            end)

          {work_type, studies}
        end)
        |> Enum.reject(fn {_type, studies} -> Enum.empty?(studies) end)

      # Filter further by work_type if not "All"
      work_type_filtered =
        if work_type_filter == "All" do
          filtered
        else
          Enum.filter(filtered, fn study ->
            Map.get(study, :work_type) == work_type_filter
          end)
        end

      socket
      |> assign(:grouped_case_studies, grouped)
      |> assign(:filtered_case_studies, work_type_filtered)
    else
      socket
      |> assign(:grouped_case_studies, [])
      |> assign(:filtered_case_studies, filtered)
    end
  end
end
