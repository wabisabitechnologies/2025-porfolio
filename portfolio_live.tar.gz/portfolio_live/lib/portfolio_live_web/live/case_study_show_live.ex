defmodule PortfolioLiveWeb.CaseStudyShowLive do
  use PortfolioLiveWeb, :live_view

  alias PortfolioLive.Content

  def mount(%{"slug" => slug}, _session, socket) do
    study = Content.case_study!(slug)

    sections = study.sections || []

    {quote_sections, content_sections} =
      Enum.split_with(sections, fn section ->
        type = to_string(section[:type] || section["type"] || "text")
        type == "quote"
      end)

    socket =
      socket
      |> assign(:study, study)
      |> assign(:profile, Content.homepage())
      |> assign(:navigation, Content.navigation())
      |> assign(:sections, content_sections)
      |> assign(:quote_sections, quote_sections)

    {:ok, socket}
  end

  def render(assigns) do
    ~H"""
    <div class="min-h-screen bg-white text-slate-900">
      <div class="mx-auto max-w-6xl space-y-10 px-6 pb-20 pt-10 sm:px-8 lg:px-10">
        <.page_header profile={@profile} navigation={@navigation} active_key="case_studies" />

        <div class="grid gap-10 lg:grid-cols-[minmax(0,1.6fr)_minmax(0,0.7fr)] lg:items-start">
          <section class="space-y-8">
            <header class="space-y-4">
              <p class="text-sm uppercase tracking-[0.3em] text-slate-400">Case Study</p>
              <h1 class="text-4xl font-semibold leading-snug"><%= @study.title %></h1>
              <p class="text-lg text-slate-600 max-w-3xl"><%= @study.summary %></p>
            </header>

            <%= for quote <- @quote_sections do %>
              <%= render_section(quote) %>
            <% end %>

            <%= if @study.hero_image do %>
              <figure class="rounded-[28px] border border-slate-200 bg-white p-4">
                <img
                  src={@study.hero_image}
                  alt={"Preview of #{@study.title}"}
                  class="aspect-[3/2] w-full rounded-2xl object-cover"
                />
              </figure>
            <% end %>

            <div class="prose prose-slate max-w-none text-slate-600">
              <%= raw(@study.body) %>
            </div>

            <%= for section <- @sections do %>
              <%= render_section(section) %>
            <% end %>

            <div class="grid gap-4 border-t border-slate-100 pt-8 sm:grid-cols-2">
              <%= for stat <- @study.stats do %>
                <div>
                  <dt class="text-xs uppercase tracking-[0.3em] text-slate-400">
                    <%= String.upcase(stat[:label] || stat["label"]) %>
                  </dt>
                  <dd class="mt-1 text-3xl font-semibold text-slate-900">
                    <%= stat[:value] || stat["value"] %>
                  </dd>
                </div>
              <% end %>
            </div>
          </section>

          <aside class="space-y-6 rounded-[24px] border border-slate-200 bg-white p-6 self-start lg:sticky lg:top-24">
            <div class="space-y-4">
              <p class="text-xs uppercase tracking-[0.3em] text-slate-400">Project context</p>
              <dl class="space-y-3 text-sm">
                <%= for entry <- @study.context || [] do %>
                  <div>
                    <dt class="text-xs uppercase tracking-[0.25em] text-slate-400">
                      <%= entry[:label] || entry["label"] %>
                    </dt>
                    <dd class="text-base font-medium text-slate-900">
                      <%= entry[:value] || entry["value"] %>
                    </dd>
                  </div>
                <% end %>
              </dl>
            </div>

            <div class="space-y-4 border-t border-slate-100 pt-4">
              <p class="text-xs uppercase tracking-[0.3em] text-slate-400">Highlights</p>
              <div class="space-y-3 text-sm">
                <%= for stat <- @study.stats do %>
                  <div>
                    <p class="text-xs uppercase tracking-[0.25em] text-slate-400">
                      <%= stat[:label] || stat["label"] %>
                    </p>
                    <p class="text-lg font-semibold text-slate-900">
                      <%= stat[:value] || stat["value"] %>
                    </p>
                  </div>
                <% end %>
              </div>
            </div>

            <div class="space-y-4 border-t border-slate-100 pt-4">
              <p class="text-xs uppercase tracking-[0.3em] text-slate-400">Collaborate</p>
              <.cta_buttons cta={@profile.cta} />
            </div>
          </aside>
        </div>
      </div>
    </div>
    """
  end

  defp render_section(section) do
    type = to_string(section[:type] || section["type"] || "text")

    case type do
      "image" ->
        assigns = %{
          src: section[:src] || section["src"],
          caption: section[:caption] || section["caption"]
        }

        ~H"""
        <figure class="rounded-[24px] border border-slate-200 bg-white p-4">
          <img src={@src} alt={@caption || "Case study image"} class="w-full rounded-2xl object-cover" />
          <%= if @caption do %>
            <figcaption class="mt-3 text-sm text-slate-500"><%= @caption %></figcaption>
          <% end %>
        </figure>
        """

      "quote" ->
        assigns = %{
          quote: section[:quote] || section["quote"],
          cite: section[:cite] || section["cite"]
        }

        ~H"""
        <blockquote class="flex gap-4 py-6 text-lg font-medium text-slate-900">
          <span class="text-6xl font-serif text-slate-200 leading-none" aria-hidden="true">“</span>
          <div class="space-y-3">
            <p><%= @quote %></p>
            <%= if @cite do %>
              <footer class="text-sm font-normal uppercase tracking-[0.3em] text-slate-400">
                <%= @cite %>
              </footer>
            <% end %>
          </div>
        </blockquote>
        """

      _ ->
        assigns = %{
          title: section[:title] || section["title"],
          body: section[:body] || section["body"] || ""
        }

        ~H"""
        <article class="space-y-3 py-6">
          <%= if @title do %>
            <h2 class="text-2xl font-semibold text-slate-900"><%= @title %></h2>
          <% end %>
          <p class="text-base text-slate-600"><%= @body %></p>
        </article>
        """
    end
  end
end
