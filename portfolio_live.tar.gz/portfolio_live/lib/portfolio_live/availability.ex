defmodule PortfolioLive.Availability do
  @threshold_days 50

  def format(%{availability_quarter: q, availability_year: y}) when q in 1..4 do
    {quarter, year} =
      case needs_next?(q, y) do
        true -> next_quarter(q, y)
        false -> {q, y}
      end

    "Available for Q#{quarter} #{year}"
  end

  def format(%{availability: text}) when is_binary(text), do: text
  def format(_), do: "Available"

  defp needs_next?(quarter, year) do
    today = Date.utc_today()
    quarter_end = quarter_end_date(quarter, year)

    Date.compare(today, quarter_end) == :gt or Date.diff(quarter_end, today) <= @threshold_days
  end

  defp quarter_end_date(1, year), do: Date.new!(year, 3, 31)
  defp quarter_end_date(2, year), do: Date.new!(year, 6, 30)
  defp quarter_end_date(3, year), do: Date.new!(year, 9, 30)
  defp quarter_end_date(4, year), do: Date.new!(year, 12, 31)

  defp next_quarter(4, year), do: {1, year + 1}
  defp next_quarter(quarter, year), do: {quarter + 1, year}
end
