defmodule PortfolioLive.Mailer do
  use Swoosh.Mailer, otp_app: :portfolio_live
end
