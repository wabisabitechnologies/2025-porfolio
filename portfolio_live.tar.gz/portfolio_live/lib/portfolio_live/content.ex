defmodule PortfolioLive.Content do
  @moduledoc """
  Public API for Markdown-driven content used throughout the site.
  """

  alias PortfolioLive.Content.{CaseStudies, Pages, TILs}

  @note_categories ["Product", "Design", "Engineering", "Business"]

  def homepage, do: Pages.homepage()
  def case_studies_page, do: Pages.get!("case-studies")
  def about_page, do: Pages.get!("about")
  def resume_page, do: Pages.get!("resume")
  def notes_page, do: Pages.get!("notes")

  def navigation, do: Pages.navigation()
  def home_filters, do: homepage().filters

  def featured_case_studies, do: CaseStudies.featured()
  def case_studies, do: CaseStudies.all()
  def case_study!(slug), do: CaseStudies.get!(slug)

  def latest_tils(limit \\ 3), do: TILs.latest(limit)

  def note_categories, do: @note_categories

  def notes_grouped do
    notes = TILs.all()
    base = Map.new(@note_categories, &{&1, []})

    grouped =
      Enum.reduce(notes, base, fn note, acc ->
        category = normalize_category(note.category)
        Map.update!(acc, category, &[note | &1])
      end)

    Enum.into(grouped, %{}, fn {category, list} -> {category, Enum.reverse(list)} end)
  end

  def notes_for_category(category) do
    normalized = normalize_category(category)
    notes_grouped() |> Map.get(normalized, [])
  end

  defp normalize_category(nil), do: hd(@note_categories)

  defp normalize_category(category) do
    Enum.find(@note_categories, hd(@note_categories), fn item ->
      String.downcase(item) == String.downcase(category)
    end)
  end
end
