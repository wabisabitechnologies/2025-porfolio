defmodule PortfolioLive.Content.CaseStudies do
  @moduledoc false

  alias PortfolioLive.Content.CaseStudy

  use NimblePublisher,
    build: CaseStudy,
    from: Application.app_dir(:portfolio_live, "priv/content/case_studies/*.md"),
    as: :case_studies,
    front_matter: :yaml

  @case_studies Enum.sort_by(@case_studies, & &1.title)

  def all, do: @case_studies

  def featured do
    Enum.filter(@case_studies, & &1.featured)
  end

  def get!(slug) do
    Enum.find(@case_studies, fn study -> study.slug == slug end) ||
      raise ArgumentError, "No case study found for #{slug}"
  end
end
