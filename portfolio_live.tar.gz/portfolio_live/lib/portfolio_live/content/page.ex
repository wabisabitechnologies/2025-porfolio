defmodule PortfolioLive.Content.Page do
  @moduledoc """
  Represents a simple Markdown-driven page (home, about, resume, etc).
  """

  @enforce_keys [:slug, :title, :summary, :body]
  defstruct [
    :slug,
    :name,
    :title,
    :summary,
    :body,
    :body_intro,
    :roles,
    :availability,
    :availability_quarter,
    :availability_year,
    :cta,
    :navigation,
    :filters,
    :sidebar_links,
    :focus_areas,
    :featured_intro,
    :profile_photo
  ]

  def build(_path, attrs, body) do
    slug =
      attrs
      |> Map.get(:slug, attrs[:title])
      |> slugify()

    attrs =
      attrs
      |> Map.put(:slug, slug)
      |> Map.put_new(:roles, [])
      |> Map.put_new(:cta, [])
      |> Map.put_new(:navigation, [])
      |> Map.put_new(:filters, [])
      |> Map.put_new(:sidebar_links, [])
      |> Map.put_new(:availability_quarter, nil)
      |> Map.put_new(:availability_year, nil)

    struct!(__MODULE__, Map.put(attrs, :body, body))
  end

  defp slugify(nil), do: "page"

  defp slugify(string) do
    string
    |> String.downcase()
    |> String.replace(~r/[^a-z0-9]+/u, "-")
    |> String.trim("-")
  end
end
