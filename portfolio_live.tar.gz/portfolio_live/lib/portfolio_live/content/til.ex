defmodule PortfolioLive.Content.TIL do
  @enforce_keys [:slug, :title, :summary, :published_at, :body]
  defstruct [:slug, :title, :summary, :published_at, :body, :category, tags: []]

  def build(_path, attrs, body) do
    slug =
      attrs
      |> Map.get(:slug, attrs[:title])
      |> slugify()

    published_at =
      case Map.get(attrs, :published_at) do
        %Date{} = date -> date
        nil -> Date.utc_today()
        value -> Date.from_iso8601!(to_string(value))
      end

    category =
      Map.get(attrs, :category) || Map.get(attrs, "category") || "Product"

    attrs =
      attrs
      |> Map.put(:slug, slug)
      |> Map.put(:published_at, published_at)
      |> Map.put(:category, category)
      |> Map.put_new(:tags, [])

    struct!(__MODULE__, Map.put(attrs, :body, body))
  end

  defp slugify(nil), do: "til"

  defp slugify(string) do
    string
    |> String.downcase()
    |> String.replace(~r/[^a-z0-9]+/u, "-")
    |> String.trim("-")
  end
end
