defmodule PortfolioLive.Content.Pages do
  @moduledoc false

  alias PortfolioLive.Content.Page

  use NimblePublisher,
    build: Page,
    from: Application.app_dir(:portfolio_live, "priv/content/pages/*.md"),
    as: :pages,
    highlighters: [:makeup_elixir],
    front_matter: :yaml

  @pages Enum.sort_by(@pages, & &1.slug)
  @homepage Enum.find(@pages, fn page -> page.slug == "home" end)

  def all, do: @pages

  def homepage, do: @homepage

  def get!(slug) do
    Enum.find(@pages, fn page -> page.slug == slug end) ||
      raise ArgumentError, "No page found for #{slug}"
  end

  def navigation do
    (homepage() && homepage().navigation) || []
  end
end
