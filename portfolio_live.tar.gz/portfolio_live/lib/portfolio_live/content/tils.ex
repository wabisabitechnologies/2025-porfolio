defmodule PortfolioLive.Content.TILs do
  @moduledoc false

  alias PortfolioLive.Content.TIL

  use NimblePublisher,
    build: TIL,
    from: Application.app_dir(:portfolio_live, "priv/content/til/*.md"),
    as: :tils,
    front_matter: :yaml

  @tils Enum.sort_by(@tils, & &1.published_at, {:desc, Date})

  def all, do: @tils

  def latest(limit \\ 3) do
    Enum.take(@tils, limit)
  end
end
