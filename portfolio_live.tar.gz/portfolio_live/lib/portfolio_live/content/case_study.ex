defmodule PortfolioLive.Content.CaseStudy do
  @enforce_keys [:slug, :title, :summary, :category, :body]
  defstruct [
    :slug,
    :title,
    :summary,
    :category,
    :body,
    :hero_image,
    :context,
    :sections,
    :work_type,
    stats: [],
    tags: [],
    featured: false
  ]

  def build(_path, attrs, body) do
    slug =
      attrs
      |> Map.get(:slug, attrs[:title])
      |> slugify()

    attrs =
      attrs
      |> Map.put(:slug, slug)
      |> Map.put_new(:stats, [])
      |> Map.put_new(:tags, [])
      |> Map.put_new(:featured, false)
      |> Map.put_new(:context, [])
      |> Map.put_new(:sections, [])

    struct!(__MODULE__, Map.put(attrs, :body, body))
  end

  defp slugify(nil), do: "case-study"

  defp slugify(string) do
    string
    |> String.downcase()
    |> String.replace(~r/[^a-z0-9]+/u, "-")
    |> String.trim("-")
  end
end
